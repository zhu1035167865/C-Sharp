﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace MyIntegerSet
{
    public class IntegerSet
    {
        private bool[] _set;
        public bool[] Set
        {
            get { return _set; }
            set { _set = value; }
        }
        public IntegerSet()
        {
            Console.Write("\n  IntegerSet Constructed");
            _set = new bool[1001];
            for (int i = 0; i < 1001; i++)
            {
                _set[i] = false;
            }
        }

        public IntegerSet(bool[] val)
            : this()
        {
            Console.Write("\n   IntegerSet Constructed with bool[]");
            int size = Math.Min(val.Length, 1001);
            for (int i = 0; i < size; i++)
            {
                _set[i] = val[i];
            }
        }
        public IntegerSet Union(IntegerSet otherSet)
        {
            IntegerSet resultSet = new IntegerSet();
            int counter = 0;

            foreach (bool value in otherSet.Set)
            {
                if (value)
                    resultSet.Set[counter] = true;
                else if (_set[counter])
                    resultSet.Set[counter] = true;
                counter++;
            }

            return resultSet;
        }

        public IntegerSet Intersection(IntegerSet otherSet)
        {
            IntegerSet resultSet = new IntegerSet();
            int counter;

            for (counter = 0; counter < 1001; counter++)
            {
                resultSet.Set[counter] = true;
            }

            counter = 0;
            foreach (bool value in otherSet.Set)
            {
                if (!value)
                    resultSet.Set[counter] = false;
                else if (!_set[counter])
                    resultSet.Set[counter] = false;
                counter++;
            }

            return resultSet;
        }

        public void InsertElement(int k)
        {
            try
            {
                _set[k] = true;
            }
            catch (Exception)
            {
                Console.WriteLine("The number " + k + " is an invalid number.\n Try again.");
            }
        }

        public void DeleteElement(int k)
        {
            try
            {
                _set[k] = false;
            }
            catch (Exception ex)
            {
                throw new Exception("The number " + k + " is an invalid number.\n Try again.", ex);
            }
        }

        public override string ToString()
        {
            string resultString = string.Empty;

            for (int i = 0; i < _set.Length; i++)
            {
                if (_set[i])
                {
                    resultString = resultString + i + ", ";
                }
            }

            return resultString;
        }

        public bool IsEqualTo(IntegerSet otherSet)
        {
            bool result = true;
            int counter = 0;

            foreach (bool value in otherSet.Set)
            {
                if (value != _set[counter])
                    result = false;
                counter++;
            }

            return result;
        }


        public void Clear()
        {
            for (int i = 0; i < _set.Length; i++)
            {
                _set[i] = false;
            }
        }
    }
}